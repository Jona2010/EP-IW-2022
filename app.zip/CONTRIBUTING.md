# Contributing to CodeIgniter4

CodeIgniter is a community driven project and accepts contributions of
code and documentation from the community.

If you'd like to contribute, please read the [Contributing to CodeIgniter](./contributing/README.md).
